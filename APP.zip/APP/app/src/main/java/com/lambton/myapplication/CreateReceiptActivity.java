package com.lambton.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.lambton.myapplication.db.DBManager;
import com.lambton.myapplication.model.Receipt;
import com.lambton.myapplication.model.ReceiptGroup;

import java.util.ArrayList;
import java.util.List;

import static com.lambton.myapplication.db.DBHelper.ALL_GROUP_ID;

public class CreateReceiptActivity extends ImagePickActivity {


    EditText etReceiptName;
    EditText etReceiptAmount;
    EditText etReceiptDescription;
    ImageView imvSnapShot;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group_receipt);

        etReceiptName = findViewById(R.id.etReceiptName);
        etReceiptAmount = findViewById(R.id.etReceiptAmount);
        etReceiptDescription = findViewById(R.id.etReceiptDescription);
        imvSnapShot = findViewById(R.id.imvSnapShot);
        spinner = findViewById(R.id.spinner);


        findViewById(R.id.btnCreateReceipt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndSave();
            }
        });

        imvSnapShot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        List<String> list = new ArrayList<>();
        list.add("ALL");

        for (ReceiptGroup receiptGroup :
                DBManager.getInstance().dbHelper.getAllGroups()) {
            list.add(receiptGroup.name);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
    }


    private void openinEditMode(Receipt receipt) {
        if (receipt.snapshotPath != null && !receipt.snapshotPath.isEmpty()) {
            Bitmap bitmap = BitmapFactory.decodeFile(receipt.snapshotPath);
            imvSnapShot.setImageBitmap(bitmap);
        }
    }

    private void validateAndSave() {

        String amount = etReceiptAmount.getText().toString();
        String desc = etReceiptDescription.getText().toString();
        String name = etReceiptName.getText().toString();
        //String selectedGroup = spinner.getSelectedItem().toString();

        if (!amount.isEmpty() && !desc.isEmpty() && !name.isEmpty()) {
            String gID;

            int pos = spinner.getSelectedItemPosition();

            if (pos == 0)
                gID = ALL_GROUP_ID;
            else {
                ReceiptGroup receiptGroup = DBManager.getInstance().dbHelper.getAllGroups().get(pos - 1);
                gID = receiptGroup.id;
            }

            String snapShotPath = "";

            if (imagePath != null)
                snapShotPath = imagePath;

            Receipt receipt = new Receipt(name, desc, amount, gID, snapShotPath);

            long id = DBManager.getInstance().dbHelper.addReceipt(receipt);
            if (id > 0) {
                Toast.makeText(this, "Your Receipt has been added :)", Toast.LENGTH_SHORT).show();
                onBackPressed();
            } else {
                Toast.makeText(this, R.string.failed_to_save, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, R.string.fill_all_details, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void setImageBitmap(Bitmap thumbnail, String path) {
        imvSnapShot.setImageBitmap(thumbnail);
        imagePath = path;
    }
}
