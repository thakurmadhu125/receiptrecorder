package com.lambton.myapplication;

import android.app.Application;
import android.content.Context;

public class AppController extends Application {

    private static AppController mInstance;

    public static Context getInstance() {
        return mInstance;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

    }
}
