package com.lambton.myapplication.model;

import android.database.Cursor;

import com.lambton.myapplication.db.DBHelper;

import java.util.Date;

public class Receipt {
    public String id;
    public String name;
    public String description;
    public String amount;
    public String snapshotPath;
    public String groupID;
    public String date;

    public Receipt(String name, String desc, String amount, String gID, String snapshotPath) {
        this.name = name;
        this.description = desc;
        this.amount = amount;
        this.groupID = gID;
        this.snapshotPath = snapshotPath;
        this.date = new Date().toString();

    }

    public Receipt(Cursor cursor) {
        id = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_ID);
        name = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_NAME);
        description = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_DESCRIPTION);
        amount = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_AMOUNT);
        groupID = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_GROUP_ID);
        snapshotPath = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_SNAPSHOP_PATH);
        date = DBHelper.getValueForColumn(cursor, DBHelper.ReceiptTable.COLUMN_DATE);
    }
}
