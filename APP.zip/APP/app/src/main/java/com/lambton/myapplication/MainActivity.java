package com.lambton.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.DataSetObserver;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.lambton.myapplication.db.DBManager;
import com.lambton.myapplication.model.User;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView tvAppName;
    TextView tvUserIntro;
    //private String[] mNavigationDrawerItemTitles;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    Toolbar toolbar;
    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    android.support.v7.app.ActionBarDrawerToggle mDrawerToggle;
    ListView lvRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        findViewById(R.id.btnModifyDetail).setOnClickListener(this);
//        findViewById(R.id.btnAddGroupReceipt).setOnClickListener(this);
//        findViewById(R.id.btnCreateReceipt).setOnClickListener(this);
//        findViewById(R.id.btnViewReceipt).setOnClickListener(this);
//
//        tvAppName = findViewById(R.id.tvAppName);
//        tvUserIntro = findViewById(R.id.tvUserIntro);

        ImageView imvMenu = findViewById(R.id.imvMenu);
        imvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.LEFT);
            }
        });

        SearchView searchBar = findViewById(R.id.searchBar);
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //Toast.makeText(MainActivity.this, "hello", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        mTitle = mDrawerTitle = getTitle();
        //mNavigationDrawerItemTitles = new {"hello"};
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);

        //setupToolbar();

        DataModel[] drawerItem = new DataModel[4];

        drawerItem[0] = new DataModel(getString(R.string.modify_your_detail));
        drawerItem[2] = new DataModel(getString(R.string.add_group_receipt));
        drawerItem[1] = new DataModel(getString(R.string.create_group));
        drawerItem[3] = new DataModel(getString(R.string.view_receipt));
        // getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        //etSupportActionBar().setHomeButtonEnabled(true);

        DrawerItemCustomAdapter adapter = new DrawerItemCustomAdapter(this, R.layout.list_view_item_row, drawerItem);
        mDrawerList.setAdapter(adapter);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        setupDrawerToggle();

        lvRecords = findViewById(R.id.lvRecords);

    }


    private class DrawerItemClickListener implements ListView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            selectItem(position);
        }
    }


    private void selectItem(int position) {
        Intent intent = null;
        switch (position) {
            case 0:
                intent = new Intent(this, UserDetailActivity.class);
                break;

            case 1:
                intent = new Intent(this, AddGroupReceiptActivity.class);
                break;

            case 2:
                intent = new Intent(this, CreateReceiptActivity.class);
                break;

            case 3:
                intent = new Intent(this, ViewReceiptActivity.class);
                break;
            default:
                break;
        }

        if (intent != null)
            startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        getSupportActionBar().setTitle(mTitle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }


    void setupDrawerToggle() {
        mDrawerToggle = new android.support.v7.app.ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.app_name, R.string.app_name);
        //This is necessary to change the icon of the Drawer Toggle upon state change.
        mDrawerToggle.syncState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<User> users = DBManager.getInstance().dbHelper.getAllUsersRecords();
        if (users.size() > 0)
            updateDetail(users.get(0));
    }

    private void updateDetail(User user) {
        // String text = "Hello, " + user.firstName + " " + user.lastName;
        //tvUserIntro.setText(text);
    }
}
